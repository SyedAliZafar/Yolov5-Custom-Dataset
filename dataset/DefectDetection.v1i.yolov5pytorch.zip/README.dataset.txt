# DefectDetection > 2023-02-22 12:46pm
https://universe.roboflow.com/access-ev/defectdetection-uqqw4

Provided by a Roboflow user
License: CC BY 4.0

